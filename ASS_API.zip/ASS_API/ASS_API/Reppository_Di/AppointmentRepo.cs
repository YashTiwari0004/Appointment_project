﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASS_API.DataAccessLayer;
using AutoMapper;
using ASS_API.Models;
using ASS_API.DbModels;
using Microsoft.EntityFrameworkCore;

namespace ASS_API.Reppository_Di
{
    enum STATUS{
        BOOKED,
        CANCELLED
    }
    public class AppointmentRepo : IAppointment
    {
        
        public readonly EfDbContext efDbContext = null;
        public readonly IMapper mapper = null;
        public AppointmentRepo(EfDbContext efDbContext, IMapper mapper)
        {
            this.efDbContext = efDbContext;
            this.mapper = mapper;
        }
        public async Task<int?> BookAppointment(AppointmentSchedulingModel book, char courtId, int custId, int staffId)
        {
            try
            {
                var newBooking = new AppointmentScheduling
                {
                    BookDate = book.BookDate,
                    StartTime = book.StartTime,
                    EndTime = book.EndTime,
                    Bookstatus = STATUS.BOOKED.ToString() ,
                    CustomerId = custId,
                    StaffId = staffId,
                    CourtId = courtId
                };
                await efDbContext.Book.AddAsync(newBooking);
                await efDbContext.SaveChangesAsync();
                return newBooking.Id;
            }
            catch
            {
                return null;
            }
        }

        public async Task<int?> CancelAppointment(int bookingId)
        {
            try
            {
                var bookin =await  efDbContext.Book.Where(e=>e.Id==bookingId).FirstOrDefaultAsync();
                if (bookin == null)
                {
                    return null;
                }
                bookin.Bookstatus = STATUS.CANCELLED.ToString();
                await efDbContext.SaveChangesAsync();
                return bookingId;

            }
            catch { return null; }
        }

        public async Task<List<AppointmentSchedulingModel>> GetAllAppointmentDetails(int id)
        {
            var list = await efDbContext.Book.Where(e => e.CustomerId == id).ToListAsync();
            return mapper.Map<List<AppointmentSchedulingModel>>(list);

        }

        public async Task<int?> RescheduleAppointment(int bookingId, AppointmentSchedulingModel book)
        {
            try
            {
                var bookin = await efDbContext.Book.Where(e => e.Id == bookingId).FirstOrDefaultAsync();
                if (bookin == null)
                {
                    return null;
                }
                bookin.StartTime = book.StartTime;
                bookin.EndTime = book.EndTime;
                bookin.BookDate = book.BookDate;
                await efDbContext.SaveChangesAsync();
                return bookingId;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}

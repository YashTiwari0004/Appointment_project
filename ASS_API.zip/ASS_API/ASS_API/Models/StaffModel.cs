﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ASS_API.Models
{
    public class StaffModel
    { 
        [Required]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public DateTime Dob { get; set; }
        [Required]
        public long MobileNumber { get; set; }
        [Required]
        public string Address { get; set; }
        
    }
}

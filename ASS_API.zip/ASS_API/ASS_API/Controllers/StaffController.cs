﻿using ASS_API.Reppository_Di;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffController : ControllerBase
    {
        private readonly IStaff _staff;

        public StaffController(IStaff staff)
        {
            _staff = staff;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetStaffDetails()
        {
            var staffList = await _staff.GetStaffdetails();
            return Ok(staffList);
        }
    }
}

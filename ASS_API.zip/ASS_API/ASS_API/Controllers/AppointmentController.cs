﻿using ASS_API.Reppository_Di;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASS_API.Models;

namespace ASS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private readonly IAppointment _appointment;

        public AppointmentController(IAppointment appointment)
        {
            _appointment = appointment;
        }

        [HttpPost("{custId}/{staffId}/{courtId}")]
        public async Task<IActionResult> BookAppointment([FromBody] AppointmentSchedulingModel appointment, [FromRoute] int custId, [FromRoute] int staffId, [FromRoute] char courtId )
        {
            var bookingId = await _appointment.BookAppointment(appointment, courtId, custId, staffId);
            if (bookingId == null)
            {
                return Ok("Something went Wrong..");
            }
            return Ok(bookingId);
        }

        [HttpDelete]
        public async Task<IActionResult> CancelAppointment([FromQuery] int Id)
        {
            var bookingId = await _appointment.CancelAppointment(Id);
            if (bookingId == null)
            {
                return NotFound("Resource Not Found");
            }
            return Ok(bookingId);
        }

        [HttpPatch("{id}")]
        public async Task<IActionResult> ReschuduleAppointment([FromRoute] int id,AppointmentSchedulingModel model)
        {
            var result = await _appointment.RescheduleAppointment(id, model);
            if (result == null)
            {
                return NotFound("Resource Not Found");
            }
            return Ok(result);
        }

        [HttpGet("/History")]
        public async Task<IActionResult> AppointmentHistory([FromQuery] int Num)
        {
            var list = await _appointment.GetAllAppointmentDetails(Num);
            if (list.Count == 0)
            {
                return NotFound("Your History is Empty Please Book Appointment");
            }
            return Ok(list);
        }

    }
}
